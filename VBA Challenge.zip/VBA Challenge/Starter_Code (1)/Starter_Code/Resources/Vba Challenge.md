 Vba Challenge

 In these files you will see two different excel files. 
 
 One is called alphabetic testing which is a testing file for vba code so that it is easier to troubleshoot errors and bugs that happen while running the vba code. This file is smaller in size which makes it faster to run and recieve feedback on what happened with the code. 
 
 The second file that is here is the multiple year stock data which is essentially a bigger version of the alphabetic testing file. In this file, there is around 100,000 rows for each quarter and there are four quarters worth of data that is about stock information(stock ticker, date, open price, close price, etc). There is a script of vba code which tries to make it easier for the reader to understand by showing the quarterly chnage, percentage change, and total volume for each individual stock ticker. It can also show which stock had the greatest percent increase and decrease as well as highest volume for all of the stocks each quarter. 